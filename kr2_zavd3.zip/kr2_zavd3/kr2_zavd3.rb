mutex = Mutex.new
cv = ConditionVariable.new

# Перший потік
thread1 = Thread.new do
  (1..10).each do |i|
    mutex.synchronize do
      puts "Thread 1: #{i}"
      cv.signal  # Сигнал для іншого потоку, що може вивести наступне число
      cv.wait(mutex) unless i == 10  # Чекаємо сигнал від іншого потоку, якщо не останнє число
    end
  end
end

# Другий потік
thread2 = Thread.new do
  (1..10).each do |i|
    mutex.synchronize do
      cv.wait(mutex)  # Чекаємо сигнал від іншого потоку, перш ніж вивести число
      puts "Thread 2: #{i}"
      cv.signal unless i == 10  # Сигнал для іншого потоку, що може вивести наступне число, якщо не останнє число
    end
  end
end

# Очікуємо завершення обох потоків
thread1.join
thread2.join


